import pandas as pd

print("--- 時系列イベントログの作成を開始します (安定版) ---")

try:
    # --- 1. データの読み込み ---
    df_disease = pd.read_csv("disease.csv")
    df_drug = pd.read_csv("drug.csv")
    df_inspection = pd.read_csv("inspection.csv")
    print("✅ 全てのファイルの読み込みに成功しました。")

    # --- 2. 各データを標準イベント形式に変換 ---
    
    # 【疾患データ】
    df_disease['event_detail'] = (
        'ICD10:' + df_disease['icd10_code'].astype(str) + ' ' + df_disease['disease_name'].astype(str)
    )
    disease_events = df_disease[['patient_id', 'disease_date', 'event_detail']].copy()
    disease_events.rename(columns={'disease_date': 'event_date'}, inplace=True)
    disease_events['event_type'] = '診断'
    
    # 【薬剤データ】
    df_drug['event_detail'] = (
        'YJ:' + df_drug['yj_code'].astype(str) + ' ' + df_drug['drug_name'].astype(str)
    )
    drug_events = df_drug[['patient_id', 'key_date', 'event_detail']].copy()
    drug_events.rename(columns={'key_date': 'event_date'}, inplace=True)
    drug_events['event_type'] = '処方'

    # 【検査データ】
    df_inspection['event_detail'] = (
        df_inspection['inspection_name'] + ': ' + df_inspection['inspection_value'].astype(str)
    )
    inspection_events = df_inspection[['patient_id', 'inspection_date', 'event_detail']].copy()
    inspection_events.rename(columns={'inspection_date': 'event_date'}, inplace=True)
    inspection_events['event_type'] = '検査'

    print("📊 各データをコード情報付きの標準イベント形式に変換しました。")

    # --- 3. 全イベントを結合・並べ替え ---
    all_events = pd.concat([disease_events, drug_events, inspection_events])

    # ✅ 日付変換を安全に（スラッシュやハイフン混在OK）
    all_events['event_date'] = pd.to_datetime(
        all_events['event_date'], errors='coerce', infer_datetime_format=True
    )

    # NaT（変換失敗行）を除外
    all_events = all_events.dropna(subset=['event_date'])

    all_events_sorted = all_events.sort_values(by=['patient_id', 'event_date']).reset_index(drop=True)

    print("✅ 全てのイベントを結合し、時系列にソートしました。")

    # --- 4. CSVファイルとして保存 ---
    all_events_sorted.to_csv("all_events.csv", index=False, encoding="utf-8-sig")
    print("💾 イベントログを 'all_events.csv' に保存しました。")

    # --- 5. 結果確認 ---
    print("\n--- 処理完了：生成されたイベントログ（先頭10件）---")
    print(all_events_sorted.head(10))

except KeyError as e:
    print(f"\nエラー: 想定される列が見つかりません: {e}")
    print("各CSVに必要な列（patient_id, disease_date, key_date, inspection_date）があるか確認してください。")
except Exception as e:
    print(f"予期せぬエラーが発生しました: {e}")
