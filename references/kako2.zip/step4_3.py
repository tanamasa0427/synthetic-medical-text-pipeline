import pandas as pd
import numpy as np
import tensorflow as tf
import pickle
import random
import time


# === 再現性＋多様性ハイブリッド設定 ===
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

def reseed_for_patient(patient_id):
    """
    各患者でシードを少しずらして、多様性を維持する。
    同じ患者IDなら毎回同じ結果になるが、
    患者ごとに軽く異なる乱数パターンになる。
    """
    local_seed = SEED + hash(str(patient_id)) % 1000
    random.seed(local_seed)
    np.random.seed(local_seed)
    tf.random.set_seed(local_seed)


# --- 静的プロフィール生成 ---
def generate_static_profile_dummy(yj_codes):
    return {
        "synthetic_patient_id": f"SYNTH_{int(time.time()*1000)}",
        "age": random.choice([40, 50, 60, 70]),
        "gender": random.choice(["男性", "女性"]),
        "base_disease_1": random.choice([
            "ICD10:I10 高血圧症",
            "ICD10:E11 2型糖尿病",
            "ICD10:E78 高脂血症"
        ]),
        "base_disease_2": random.choice([
            "ICD10:M10 痛風",
            "ICD10:I25 虚血性心疾患",
            "ICD10:N18 慢性腎臓病"
        ])
    }


# --- LSTMモデルによるイベント生成 ---
def generate_timeline_real(model, tokenizer, seed_events_list, num_events, max_len, temperature=0.7):
    input_text = " ".join(seed_events_list)
    generated_events = seed_events_list.copy()

    for _ in range(num_events):
        sequence = tokenizer.texts_to_sequences([input_text])
        sequence = tf.keras.preprocessing.sequence.pad_sequences(sequence, maxlen=max_len)

        preds = model.predict(sequence, verbose=0)[0]
        preds = np.asarray(preds).astype("float64")

        # 温度スケーリング
        preds = np.log(preds + 1e-8) / temperature
        exp_preds = np.exp(preds)
        preds = exp_preds / np.sum(exp_preds)

        next_index = np.random.choice(len(preds), p=preds)
        next_word = tokenizer.index_word.get(next_index, "")

        if next_word == "":
            break

        generated_events.append(next_word)
        input_text += " " + next_word

        if len(generated_events) > max_len:
            break

    timeline = [{"event_id": i + 1, "event_text": evt} for i, evt in enumerate(generated_events)]
    return timeline


# --- メインパイプライン ---
def main_pipeline(df_pharmacy, lstm_model, tokenizer, num_patients_to_generate=5):
    print(f"--- 疑似患者データ生成パイプラインを開始 ({num_patients_to_generate}人分) ---")
    all_patients_list = []
    all_events_list = []

    unique_pharmacy_prescriptions = df_pharmacy.groupby("patient_id").apply(
        lambda x: list(zip(x["yj_code"], x["product_name"]))
    )

    for i, (patient_id, prescriptions) in enumerate(unique_pharmacy_prescriptions.items()):
        if i >= num_patients_to_generate:
            break

        reseed_for_patient(patient_id)  # 各患者ごとにシードを再設定

        print(f"\n--- [{i+1}/{num_patients_to_generate}] 患者 {patient_id} のデータを生成 ---")

        static_profile = generate_static_profile_dummy([p[0] for p in prescriptions])
        first_yj, first_drug = prescriptions[0]
        seed_events = [
            f"診断: {static_profile['base_disease_1']}",
            "検査: 初診時検査",
            f"処方: YJ:{first_yj} {first_drug}"
        ]

        timeline_events = generate_timeline_real(
            lstm_model, tokenizer, seed_events,
            num_events=15, max_len=50, temperature=0.7
        )

        df_patient = pd.DataFrame([static_profile])
        df_events = pd.DataFrame(timeline_events)
        if not df_events.empty:
            df_events["synthetic_patient_id"] = static_profile["synthetic_patient_id"]

        all_patients_list.append(df_patient)
        all_events_list.append(df_events)

    if all_patients_list:
        final_patients_df = pd.concat(all_patients_list, ignore_index=True)
        final_events_df = pd.concat(all_events_list, ignore_index=True)

        print("\n\n--- 全患者の生成処理完了 ---")
        final_patients_df.to_csv("synthetic_patients.csv", index=False, encoding="utf-8-sig")
        final_events_df.to_csv("synthetic_events.csv", index=False, encoding="utf-8-sig")
        print("💾 結果を 'synthetic_patients.csv' と 'synthetic_events.csv' に保存しました。")


# --- 実行ブロック ---
if __name__ == "__main__":
    print("--- 学習済みモデルとデータを読み込んでいます... ---")
    lstm_model = tf.keras.models.load_model("lstm_model.h5")
    with open("tokenizer.pkl", "rb") as handle:
        tokenizer = pickle.load(handle)

    df_pharmacy = pd.read_csv("prescription.csv", usecols=["patient_id", "product_name", "yj_code"])
    print("✅ モデル、Tokenizer、調剤薬局データの読み込みに成功しました。")

    main_pipeline(df_pharmacy, lstm_model, tokenizer, num_patients_to_generate=5)
