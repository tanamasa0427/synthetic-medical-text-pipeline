import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Bidirectional
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import pickle
from sklearn.utils.class_weight import compute_class_weight

# --- 1. イベントログの読み込み ---
try:
    # Colabのセッションストレージにアップロードしたファイル名を指定
    all_events = pd.read_csv("all_events.csv")
    print("✅ all_events.csv の読み込みに成功しました。")
except FileNotFoundError:
    print("エラー: Colab環境に all_events.csv をアップロードしてください。")
    exit()

all_events['event_full'] = all_events['event_type'].astype(str) + ": " + all_events['event_detail'].astype(str)

# --- 2. データ前処理 ---
print("\n--- AIモデルのためのデータ前処理を開始 ---")
patient_sequences_text = all_events.groupby('patient_id')['event_full'].apply(list)
tokenizer = Tokenizer(filters='', lower=False, split='뷁')
tokenizer.fit_on_texts(patient_sequences_text)
vocab_size = len(tokenizer.word_index) + 1
print(f"ユニークなイベントの種類（語彙数）: {vocab_size}")

patient_sequences_int = tokenizer.texts_to_sequences(patient_sequences_text)
X, y = [], []
for seq in patient_sequences_int:
    for i in range(1, len(seq)):
        X.append(seq[:i])
        y.append(seq[i])

if not X:
    print("学習データが生成されませんでした。処理を中断します。")
    exit()

max_seq_length = max([len(seq) for seq in X])
X_padded = pad_sequences(X, maxlen=max_seq_length, padding='pre')
y_array = np.array(y)
print("--- 前処理完了 ---")

# --- データバランスの調整 (Class Weight) ---
class_labels = np.unique(y_array)
class_weights_array = compute_class_weight(
    class_weight='balanced',
    classes=class_labels,
    y=y_array
)
class_weights = dict(zip(class_labels, class_weights_array))
print("📊 データバランス調整のためのクラス重みを計算しました。")

# --- 3. LSTMモデルの構築と学習 (改善版) ---
print("\n--- LSTMモデルの構築と学習を開始 (改善版) ---")
model = Sequential([
    Embedding(input_dim=vocab_size, output_dim=128, input_length=max_seq_length),
    Bidirectional(LSTM(150, return_sequences=True)),
    Bidirectional(LSTM(150)),
    Dense(vocab_size, activation='softmax')
])

model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model.summary()
model.fit(X_padded, y_array, epochs=50, verbose=1, class_weight=class_weights)
print("--- 学習完了 ---")

# --- 4. 学習済みモデルとTokenizerの保存 ---
model.save('lstm_model_v2.h5')
with open('tokenizer_v2.pkl', 'wb') as handle:
    pickle.dump(tokenizer, handle, protocol=pickle.HIGHEST_PROTOCOL)
print("\n💾 改善版モデルを 'lstm_model_v2.h5' に、Tokenizerを 'tokenizer_v2.pkl' に保存しました。")
print("（これらのファイルはColabのファイルブラウザからダウンロードできます）")

# --- 5. 新しいタイムラインの生成 (改善版) ---
print("\n--- 学習済みモデルを使って新しいタイムラインを生成 (改善版) ---")
def sample_with_temperature(predictions, temperature=1.0):
    predictions = np.asarray(predictions).astype('float64')
    predictions = np.log(predictions) / temperature
    exp_preds = np.exp(predictions)
    predictions = exp_preds / np.sum(exp_preds)
    probas = np.random.multinomial(1, predictions, 1)
    return np.argmax(probas)

def generate_timeline(model, tokenizer, seed_text, num_events_to_generate, max_seq_length, temperature=1.0):
    generated_sequence = [seed_text]
    for _ in range(num_events_to_generate):
        token_list = tokenizer.texts_to_sequences(generated_sequence)
        token_list_padded = pad_sequences(token_list, maxlen=max_seq_length, padding='pre')
        predicted_probs = model.predict(token_list_padded, verbose=0)[0]
        predicted_token = sample_with_temperature(predicted_probs, temperature)
        if predicted_token == 0: break
        output_word = tokenizer.index_word.get(predicted_token, '')
        generated_sequence.append(output_word)
    return generated_sequence

seed_event = '診断: ICD10:I10 高血圧症' 
new_timeline = generate_timeline(model, tokenizer, seed_event, 10, max_seq_length, temperature=1.0)

print(f"\n▼ 「{seed_event}」から始まる仮想タイムライン (temperature=1.0):")
for i, event in enumerate(new_timeline):
    print(f"  Event {i+1}: {event}")