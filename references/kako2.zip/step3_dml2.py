# ===========================================================
# step3_dml_fast.py : DirectML / CPU 最適化版（高速・軽量 GRU）
# ===========================================================

import os
os.environ["TF_USE_DIRECTML"] = "1"  # DirectML強制使用
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"  # CUDAがある場合も無効化してDML優先

import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, GRU, Dense, Bidirectional
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.utils.class_weight import compute_class_weight
import pickle

# ===========================================================
# 0️⃣ Mixed precision & Device設定
# ===========================================================
try:
    tf.keras.mixed_precision.set_global_policy('mixed_float16')
    print("✅ Mixed Precision (float16) モード有効化")
except Exception as e:
    print("⚠️ Mixed Precision無効:", e)

devices = tf.config.list_physical_devices()
print("🔍 利用可能デバイス:")
for d in devices:
    print(" -", d)

try:
    gpus = tf.config.list_physical_devices('GPU')
    if gpus:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        print("✅ GPUメモリ制御を有効化しました。")
    else:
        print("⚠️ GPUが見つかりません。CPUモードで動作します。")
except Exception as e:
    print("⚠️ GPU設定エラー:", e)

# ===========================================================
# 1️⃣ データ読み込み
# ===========================================================
try:
    all_events = pd.read_csv("all_events.csv")
    print("✅ all_events.csv の読み込みに成功しました。")
except FileNotFoundError:
    print("❌ all_events.csv が見つかりません。スクリプトと同じフォルダに配置してください。")
    exit()

# ===========================================================
# 2️⃣ データ前処理
# ===========================================================
print("\n--- データ前処理 ---")
all_events['event_full'] = all_events['event_type'].astype(str) + ": " + all_events['event_detail'].astype(str)

patient_sequences_text = all_events.groupby('patient_id')['event_full'].apply(list)
tokenizer = Tokenizer(filters='', lower=False, split='뷁')
tokenizer.fit_on_texts(patient_sequences_text)
vocab_size = len(tokenizer.word_index) + 1
print(f"ユニークイベント数: {vocab_size}")

patient_sequences_int = tokenizer.texts_to_sequences(patient_sequences_text)

X, y = [], []
for seq in patient_sequences_int:
    for i in range(1, len(seq)):
        X.append(seq[:i])
        y.append(seq[i])

if not X:
    print("❌ 学習データが空です。処理を終了します。")
    exit()

max_seq_length = min(256, max(len(seq) for seq in X))  # 512→256に短縮
X_padded = pad_sequences(X, maxlen=max_seq_length, padding='pre')
y_array = np.array(y)
print(f"最大シーケンス長: {max_seq_length}")
print("--- 前処理完了 ---")

# ===========================================================
# 3️⃣ クラス重み計算
# ===========================================================
class_labels = np.unique(y_array)
label_mapping = {old: new for new, old in enumerate(class_labels)}
y_array = np.array([label_mapping[v] for v in y_array])
class_labels = np.unique(y_array)
class_weights_array = compute_class_weight(class_weight='balanced', classes=class_labels, y=y_array)
class_weights = dict(zip(class_labels, class_weights_array))
print(f"⚙️ {len(class_labels)}クラスに対して重みを計算しました。")

# ===========================================================
# 4️⃣ モデル構築（GRU + Bidirectional）
# ===========================================================
print("\n--- モデル構築 ---")
model = Sequential([
    Embedding(input_dim=vocab_size, output_dim=64, input_length=max_seq_length),
    Bidirectional(GRU(64, return_sequences=True, dropout=0.1, recurrent_dropout=0.1)),
    Bidirectional(GRU(64, dropout=0.1, recurrent_dropout=0.1)),
    Dense(vocab_size, activation='softmax', dtype='float32')  # float32で出力安定化
])

model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model.summary()

# ===========================================================
# 5️⃣ 学習
# ===========================================================
batch_size = 4  # 低メモリ環境ではこれが最適
print(f"\n--- 学習開始 (batch_size={batch_size}) ---")
model.fit(X_padded, y_array, epochs=10, verbose=1, batch_size=batch_size, class_weight=class_weights)
print("--- 学習完了 ---")

# ===========================================================
# 6️⃣ 保存
# ===========================================================
model.save('lstm_model_dml_fast.h5')
with open('tokenizer_dml_fast.pkl', 'wb') as f:
    pickle.dump(tokenizer, f)
print("💾 モデルを 'lstm_model_dml_fast.h5'、トークナイザーを 'tokenizer_dml_fast.pkl' に保存しました。")

# ===========================================================
# 7️⃣ 推論（サンプル生成）
# ===========================================================
def sample_with_temperature(predictions, temperature=1.0):
    predictions = np.asarray(predictions).astype('float64')
    predictions = np.log(predictions + 1e-8) / temperature
    exp_preds = np.exp(predictions)
    predictions = exp_preds / np.sum(exp_preds)
    return np.argmax(np.random.multinomial(1, predictions, 1))

def generate_timeline(model, tokenizer, seed_text, num_events_to_generate, max_seq_length, temperature=1.0):
    generated = [seed_text]
    for _ in range(num_events_to_generate):
        token_list = tokenizer.texts_to_sequences(generated)
        token_list_padded = pad_sequences(token_list, maxlen=max_seq_length, padding='pre')
        predicted_probs = model.predict(token_list_padded, verbose=0)[0]
        predicted_token = sample_with_temperature(predicted_probs, temperature)
        if predicted_token == 0:
            break
        word = tokenizer.index_word.get(predicted_token, '')
        generated.append(word)
    return generated

seed_event = '診断: ICD10:I10 高血圧症'
timeline = generate_timeline(model, tokenizer, seed_event, 5, max_seq_length)
print(f"\n🧠 生成結果: {timeline}")
