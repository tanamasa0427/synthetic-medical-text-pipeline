# ===========================================================
# step4_pipeline_cpu.py : 疑似患者生成パイプライン（CPU版）
# ===========================================================
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"  # GPU無効化
os.environ["TF_USE_DIRECTML"] = "0"

import tensorflow as tf
import numpy as np
import pandas as pd
import pickle
from datetime import datetime

# ===========================================================
# 1️⃣ モデルとトークナイザーの読み込み
# ===========================================================
print("📂 モデルとトークナイザーを読み込み中...")
try:
    model = tf.keras.models.load_model("lstm_model.h5")
    with open("tokenizer.pkl", "rb") as f:
        tokenizer = pickle.load(f)
    print("✅ モデルとトークナイザーの読み込み完了")
except Exception as e:
    print(f"❌ モデルの読み込みに失敗しました: {e}")
    exit()

max_seq_length = model.input_shape[1]
print(f"🔢 モデル入力長: {max_seq_length}")

# ===========================================================
# 2️⃣ ダミー静的AI（疑似患者プロフィール生成）
# ===========================================================
def generate_static_profile_dummy(yj_codes):
    print(f"\n[静的AI] YJコード {yj_codes} から基本プロフィールを生成中...")
    profile = {
        'synthetic_patient_id': f"SYNTH_{datetime.now().strftime('%H%M%S')}",
        'age': np.random.randint(40, 80),
        'gender': np.random.choice(['男性', '女性']),
        'base_disease_1': 'ICD10:I10 高血圧症',
        'base_disease_2': 'ICD10:E11 2型糖尿病'
    }
    return profile

# ===========================================================
# 3️⃣ 時系列AI（LSTMモデルによるイベント生成）
# ===========================================================
def sample_with_temperature(predictions, temperature=1.0):
    predictions = np.asarray(predictions).astype('float64')
    predictions = np.log(predictions + 1e-8) / temperature
    exp_preds = np.exp(predictions)
    predictions = exp_preds / np.sum(exp_preds)
    return np.argmax(np.random.multinomial(1, predictions, 1))

def generate_timeline(model, tokenizer, seed_text, num_events, max_len, temperature=1.0):
    print(f"\n[時系列AI] シード「{seed_text}」からイベントを生成中...")
    generated = [seed_text]
    for _ in range(num_events):
        token_list = tokenizer.texts_to_sequences(generated)
        token_list_padded = tf.keras.preprocessing.sequence.pad_sequences(token_list, maxlen=max_len, padding='pre')
        predicted_probs = model.predict(token_list_padded, verbose=0)[0]
        predicted_token = sample_with_temperature(predicted_probs, temperature)
        if predicted_token == 0:
            break
        word = tokenizer.index_word.get(predicted_token, '')
        generated.append(word)

    timeline = []
    for event_full in generated:
        parts = event_full.split(': ', 1)
        if len(parts) == 2:
            timeline.append({'event_type': parts[0], 'event_detail': parts[1]})
    return timeline

# ===========================================================
# 4️⃣ パイプライン本体
# ===========================================================
def main_pipeline():
    print("\n🚀 疑似患者生成パイプライン開始")

    # フェーズ1
    yj_codes = ['2149025F1029']
    static_profile = generate_static_profile_dummy(yj_codes)

    # フェーズ2
    seed_event = f"診断: {static_profile['base_disease_1']}"
    timeline = generate_timeline(model, tokenizer, seed_event, num_events=10, max_len=max_seq_length, temperature=0.8)

    # 出力DataFrame
    df_patient = pd.DataFrame([static_profile])
    df_timeline = pd.DataFrame(timeline)
    df_timeline['synthetic_patient_id'] = static_profile['synthetic_patient_id']

    # 結果表示
    print("\n📋 患者プロフィール")
    print(df_patient.to_markdown(index=False))
    print("\n🧩 生成イベント")
    print(df_timeline.to_markdown(index=False))

    # 保存
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    patient_file = f"patient_profile_{timestamp}.csv"
    timeline_file = f"timeline_events_{timestamp}.csv"

    df_patient.to_csv(patient_file, index=False, encoding='utf-8-sig')
    df_timeline.to_csv(timeline_file, index=False, encoding='utf-8-sig')

    print(f"\n💾 ファイル保存完了：\n - {patient_file}\n - {timeline_file}")

# ===========================================================
# 5️⃣ 実行
# ===========================================================
if __name__ == "__main__":
    main_pipeline()
