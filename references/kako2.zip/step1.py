import pandas as pd

print("--- 病院データの統合と整形処理を開始します ---")

try:
    # --- 1. データの読み込み ---
    df_gender = pd.read_csv("gender.csv")
    df_disease = pd.read_csv("disease.csv")
    df_inspection = pd.read_csv("inspection.csv")
    df_drug = pd.read_csv("drug.csv")  # 病院処方データ
    print("✅ 全てのファイルの読み込みに成功しました。")

    # --- 2. 各データを「ワイド形式」に変換 ---

    # 【疾患データ】
    df_disease["value"] = 1
    disease_wide = df_disease.pivot_table(
        index="patient_id",
        columns="disease_name",
        values="value",
        fill_value=0
    )
    print(f"📊 疾患データを {disease_wide.shape[1]} の列に変換しました。")

    # 【検査データ】
    df_inspection["inspection_value"] = (
        df_inspection["inspection_value"]
        .astype(str)
        .str.replace(r"[^\d\.\-]", "", regex=True)
    )
    df_inspection["inspection_value"] = pd.to_numeric(
        df_inspection["inspection_value"], errors="coerce"
    )

    inspection_wide = (
        df_inspection
        .dropna(subset=["inspection_value"])
        .groupby(["patient_id", "inspection_name"])["inspection_value"]
        .mean()
        .unstack()
    )
    print(f"📊 検査データを {inspection_wide.shape[1]} の列に変換しました。")

    # 【薬剤データ】
    df_drug["value"] = 1
    drug_wide = df_drug.pivot_table(
        index="patient_id",
        columns="drug_name",
        values="value",
        fill_value=0
    )
    print(f"📊 病院処方データを {drug_wide.shape[1]} の列に変換しました。")

    # --- 3. 全てのワイドデータを結合 ---
    patient_final_df = df_gender.set_index("patient_id")

    for df in [disease_wide, inspection_wide, drug_wide]:
        patient_final_df = patient_final_df.join(df)

    patient_final_df = patient_final_df.fillna(0)
    print("✅ 全てのデータを1つに結合しました。")

    # --- 4. CSVファイルとして保存 ---
    patient_final_df.to_csv("patient_final.csv", index=True, encoding="utf-8-sig")
    print("💾 統合データを 'patient_final.csv' に保存しました。")

    # --- 5. 結果の確認 ---
    print("\n--- 処理完了：変換後のデータ（先頭5件）---")
    print(patient_final_df.head())
    print(f"\n最終的なデータの形状: {patient_final_df.shape[0]}行 (患者数), {patient_final_df.shape[1]}列 (特徴数)")

except FileNotFoundError as e:
    print(f"エラー: ファイルが見つかりません。{e}")
    print("コードを実行する場所と、CSVファイルが同じフォルダにあるか確認してください。")

except Exception as e:
    print(f"予期せぬエラーが発生しました: {e}")
