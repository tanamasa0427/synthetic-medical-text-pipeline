# ===========================================================
# step3_cpu_fast.py : CPU (oneDNN最適化) 版 - 軽量高速モデル
# ===========================================================

import os
# GPUを完全無効化してCPU専用モードにする
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ["TF_USE_DIRECTML"] = "0"

import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, GRU, Dense, Bidirectional
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.utils.class_weight import compute_class_weight
import pickle
import time

# ===========================================================
# 1️⃣ CPUデバイス確認
# ===========================================================
devices = tf.config.list_physical_devices()
print("🔍 利用可能デバイス:")
for d in devices:
    print(" -", d)

cpu_devices = tf.config.list_physical_devices('CPU')
if cpu_devices:
    print("✅ CPUモードで実行中（oneDNN最適化有効）")
else:
    print("❌ CPUデバイスが見つかりません。環境を確認してください。")

# ===========================================================
# 2️⃣ データ読み込み
# ===========================================================
try:
    all_events = pd.read_csv("all_events.csv")
    print("✅ all_events.csv の読み込みに成功しました。")
except FileNotFoundError:
    print("❌ all_events.csv が見つかりません。スクリプトと同じフォルダに配置してください。")
    exit()

# ===========================================================
# 3️⃣ データ前処理
# ===========================================================
print("\n--- データ前処理 ---")
all_events['event_full'] = all_events['event_type'].astype(str) + ": " + all_events['event_detail'].astype(str)
patient_sequences_text = all_events.groupby('patient_id')['event_full'].apply(list)

tokenizer = Tokenizer(filters='', lower=False, split='뷁')
tokenizer.fit_on_texts(patient_sequences_text)
vocab_size = len(tokenizer.word_index) + 1
print(f"ユニークイベント数: {vocab_size}")

patient_sequences_int = tokenizer.texts_to_sequences(patient_sequences_text)

X, y = [], []
for seq in patient_sequences_int:
    for i in range(1, len(seq)):
        X.append(seq[:i])
        y.append(seq[i])

if not X:
    print("❌ 学習データが空です。終了します。")
    exit()

max_seq_length = min(128, max(len(seq) for seq in X))  # 256→128に短縮
X_padded = pad_sequences(X, maxlen=max_seq_length, padding='pre')
y_array = np.array(y)
print(f"最大シーケンス長: {max_seq_length}")
print("--- 前処理完了 ---")

# ===========================================================
# 4️⃣ クラス重み計算
# ===========================================================
class_labels = np.unique(y_array)
label_mapping = {old: new for new, old in enumerate(class_labels)}
y_array = np.array([label_mapping[v] for v in y_array])
class_labels = np.unique(y_array)
class_weights_array = compute_class_weight(class_weight='balanced', classes=class_labels, y=y_array)
class_weights = dict(zip(class_labels, class_weights_array))
print(f"⚙️ {len(class_labels)}クラスに対して重みを計算しました。")

# ===========================================================
# 5️⃣ モデル構築（軽量GRU版）
# ===========================================================
print("\n--- モデル構築 ---")
model = Sequential([
    Embedding(input_dim=vocab_size, output_dim=32, input_length=max_seq_length),
    Bidirectional(GRU(32, return_sequences=True, dropout=0.1, recurrent_dropout=0.1)),
    Bidirectional(GRU(32, dropout=0.1, recurrent_dropout=0.1)),
    Dense(vocab_size, activation='softmax')
])

model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model.summary()

# ===========================================================
# 6️⃣ 学習
# ===========================================================
batch_size = 8
epochs = 5
print(f"\n--- 学習開始 (CPUモード, batch_size={batch_size}, epochs={epochs}) ---")
start = time.time()

model.fit(X_padded, y_array, epochs=epochs, verbose=1, batch_size=batch_size, class_weight=class_weights)

elapsed = time.time() - start
print(f"--- 学習完了: {elapsed/60:.2f} 分 ---")

# ===========================================================
# 7️⃣ 保存
# ===========================================================
model.save('gru_model_cpu_fast.h5')
with open('tokenizer_cpu_fast.pkl', 'wb') as f:
    pickle.dump(tokenizer, f)
print("💾 モデルを 'gru_model_cpu_fast.h5'、トークナイザーを 'tokenizer_cpu_fast.pkl' に保存しました。")

# ===========================================================
# 8️⃣ 推論（サンプル生成）
# ===========================================================
def sample_with_temperature(predictions, temperature=1.0):
    predictions = np.asarray(predictions).astype('float64')
    predictions = np.log(predictions + 1e-8) / temperature
    exp_preds = np.exp(predictions)
    predictions = exp_preds / np.sum(exp_preds)
    return np.argmax(np.random.multinomial(1, predictions, 1))

def generate_timeline(model, tokenizer, seed_text, num_events_to_generate, max_seq_length, temperature=1.0):
    generated = [seed_text]
    for _ in range(num_events_to_generate):
        token_list = tokenizer.texts_to_sequences(generated)
        token_list_padded = pad_sequences(token_list, maxlen=max_seq_length, padding='pre')
        predicted_probs = model.predict(token_list_padded, verbose=0)[0]
        predicted_token = sample_with_temperature(predicted_probs, temperature)
        if predicted_token == 0:
            break
        word = tokenizer.index_word.get(predicted_token, '')
        generated.append(word)
    return generated

seed_event = '診断: ICD10:I10 高血圧症'
timeline = generate_timeline(model, tokenizer, seed_event, 5, max_seq_length)
print(f"\n🧠 生成結果: {timeline}")
