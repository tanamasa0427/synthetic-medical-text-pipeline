# step1.py  (修正版)
import pandas as pd

print("--- Step1: 調剤データ整形（年齢・性別・処方間隔付き）---")

try:
    # === 1. データ読み込み ===
    df = pd.read_csv("prescription.csv")

    # === 2. 列名のマッピング ===
    # あなたの prescription.csv に合わせて正規化
    df = df.rename(columns={
        "dispense_date": "key_date",     # 処方日
        "yj_code": "yj_code",            # 医薬品コード
        "product_name": "product_name",  # 医薬品名
        "gender": "gender",              # 性別
        "age_group": "age_group"         # 年齢階級（ここからageを導出）
    })

    # === 3. 年齢の簡易化 ===
    # age_group の例: "60-69歳" → "65"
    def extract_age(s):
        if pd.isna(s): return None
        import re
        m = re.search(r"(\d+)", str(s))
        return int(m.group(1)) if m else None
    df["age"] = df["age_group"].apply(extract_age)

    # === 4. イベント整形 ===
    df["event_type"] = "処方"
    df["event_date"] = pd.to_datetime(df["key_date"], errors="coerce")
    df["event_detail"] = "YJ:" + df["yj_code"].astype(str) + " " + df["product_name"].astype(str)

    # === 5. 時系列ソート + 日数差分 ===
    df = df.sort_values(["patient_id", "event_date"])
    df["days_since_prev"] = (
        df.groupby("patient_id")["event_date"].diff().dt.days.fillna(0).astype(int)
    )

    df["event_full"] = (
        df["event_type"] + ": " + df["event_detail"] +
        " (+" + df["days_since_prev"].astype(str) + "d)"
    )

    # === 6. 性別・年齢の属性トークン付与 ===
    if {"age", "gender"}.issubset(df.columns):
        df["static_info"] = (
            "年齢:" + df["age"].astype(str) + " 性別:" + df["gender"].astype(str)
        )
    else:
        df["static_info"] = "年齢:不明 性別:不明"

    # === 7. 出力 ===
    df.to_csv("pharmacy_events.csv", index=False, encoding="utf-8-sig")

    print("💾 'pharmacy_events.csv' を出力しました。")
    print(f"患者数: {df['patient_id'].nunique()}, イベント数: {len(df)}")

except Exception as e:
    print("❌ エラー:", e)
