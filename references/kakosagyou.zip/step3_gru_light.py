# step3_gru_light.py
import pandas as pd, numpy as np, tensorflow as tf, pickle, ctypes
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, GRU, Dense, Bidirectional
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tqdm import tqdm

print("--- Step3: 軽量テスト版 GRU 転移学習 ---")

# === Windowsスリープ防止 ===
try:
    ES_CONTINUOUS = 0x80000000
    ES_SYSTEM_REQUIRED = 0x00000001
    ES_DISPLAY_REQUIRED = 0x00000002
    ctypes.windll.kernel32.SetThreadExecutionState(
        ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
    )
    print("💡 スリープ防止モードを有効化しました。")
except Exception as e:
    print("⚠️ スリープ防止設定に失敗:", e)

# === 1. データ読み込み & サンプリング ===
pharm = pd.read_csv("pharmacy_events.csv").head(300)
hosp = pd.read_csv("all_events.csv").head(300)

pharm_text = pharm.groupby("patient_id")["event_full"].apply(list)
hosp_text = hosp.groupby("patient_id")["event_detail"].apply(list)

# === 2. トークナイザ構築（上位3,000語のみ）===
tokenizer = Tokenizer(num_words=3000, filters='', lower=False, split=' ', oov_token="<unk>")
tokenizer.fit_on_texts(pharm_text.apply(" ".join).tolist() + hosp_text.apply(" ".join).tolist())
vocab_size = len(tokenizer.word_index) + 1

def build_xy(seqs):
    X, y = [], []
    for seq in tqdm(seqs, desc="🔧 シーケンス構築中"):
        for i in range(1, len(seq)):
            X.append(seq[:i])
            y.append(seq[i])
    return X, y

def pad_xy(X, y):
    max_len = max(map(len, X))
    return pad_sequences(X, maxlen=max_len, padding='pre'), np.array(y), max_len

# === 3. 調剤データで事前学習 ===
print("\n🧠 調剤データ準備中...")
pharm_seq = tokenizer.texts_to_sequences(pharm_text.apply(" ".join))
X_p, y_p = build_xy(pharm_seq)
X_p, y_p, max_len = pad_xy(X_p, y_p)

model = Sequential([
    Embedding(vocab_size, 128, input_length=max_len),
    Bidirectional(GRU(128, return_sequences=True)),
    Bidirectional(GRU(128)),
    Dense(vocab_size, activation='softmax')
])
model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=[
        tf.keras.metrics.SparseCategoricalAccuracy(name="acc"),
        tf.keras.metrics.SparseTopKCategoricalAccuracy(k=5, name="top5")
    ],
)

callbacks = [
    EarlyStopping(monitor='val_loss', patience=2, restore_best_weights=True),
    ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=1)
]

print("\n🧠 調剤データで事前学習開始（最大3エポック）")
model.fit(
    X_p, y_p,
    epochs=3,
    batch_size=256,
    validation_split=0.1,
    callbacks=callbacks,
    verbose=1
)

# === 4. 病院データで転移学習 ===
print("\n🏥 病院データで転移学習開始（最大2エポック）")
hosp_seq = tokenizer.texts_to_sequences(hosp_text.apply(" ".join))
X_h, y_h = build_xy(hosp_seq)
X_h, y_h, _ = pad_xy(X_h, y_h)

model.fit(
    X_h, y_h,
    epochs=2,
    batch_size=256,
    validation_split=0.1,
    callbacks=callbacks,
    verbose=1
)

# === 5. モデル保存 ===
model.save("gru_model_light.h5")
with open("tokenizer_light.pkl", "wb") as f:
    pickle.dump(tokenizer, f)
print("💾 モデルとトークナイザを保存しました。")

# === スリープ防止解除 ===
try:
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
    print("🛌 スリープ防止を解除しました。")
except:
    pass

print("✅ 軽量版の実行が完了しました。")
