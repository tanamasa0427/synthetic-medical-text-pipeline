# ============================================================
# step4_generate_long.py
# Attention-GRU 生成モデル（自然で長い生成 + 検査値再数値化）
# ============================================================

import tensorflow as tf
import numpy as np
import pickle, json, re, pandas as pd, time

print("--- Step4: Attention-GRU モデルによる長文生成 + 検査値再数値化 ---")

# === 0. カスタムレイヤー定義 ===
from tensorflow.keras.layers import Layer

class ScaledSelfAttention(Layer):
    def __init__(self, units=64, **kwargs):
        super(ScaledSelfAttention, self).__init__(**kwargs)
        self.units = units

    def build(self, input_shape):
        self.Wq = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wk = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wv = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        super().build(input_shape)

    def call(self, x):
        Q = tf.matmul(x, self.Wq)
        K = tf.matmul(x, self.Wk)
        V = tf.matmul(x, self.Wv)
        scores = tf.matmul(Q, K, transpose_b=True) / tf.sqrt(tf.cast(self.units, tf.float32))
        weights = tf.nn.softmax(scores, axis=-1)
        context = tf.matmul(weights, V)
        return tf.reduce_mean(context, axis=1)

# === 1. モデル・トークナイザ・レンジ読込 ===
model = tf.keras.models.load_model(
    "gru_attention_gen.h5",  # ← 生成モデル
    compile=False,
    custom_objects={"ScaledSelfAttention": ScaledSelfAttention}
)
with open("tokenizer_attention_gen.pkl", "rb") as f:
    tokenizer = pickle.load(f)
with open("inspection_ranges.json", "r", encoding="utf-8") as f:
    RANGE_TABLE = json.load(f)

# === 2. 補助関数 ===
def sample_from_range(name, cat):
    if name not in RANGE_TABLE or cat not in RANGE_TABLE[name]:
        return np.nan
    low, high = RANGE_TABLE[name][cat]
    if np.isnan(low) or np.isnan(high) or low >= high:
        return np.nan
    mean, std = (low + high) / 2, (high - low) / 6
    val = np.random.normal(mean, std)
    return round(float(np.clip(val, low, high)), 1)

def restore_value(text):
    m = re.search(r"検査[:：]\s*([A-Za-z0-9一-龥\-]+)\s*[:：]\s*(低|正常|高)", text)
    if not m:
        return text
    name, cat = m.groups()
    val = sample_from_range(name, cat)
    return f"検査: {name}:{val}"

# === 3. 生成関数 ===
def generate(seed, steps=120, temperature=1.15):
    """
    seed: 初期シーケンス（リスト）
    steps: 生成する単語数（多いほど長く）
    temperature: 確率分布の滑らかさ（高いほど多様）
    """
    text = " ".join(seed)
    generated = seed.copy()

    for i in range(steps):
        seq = tokenizer.texts_to_sequences([text])
        seq = tf.keras.preprocessing.sequence.pad_sequences(seq, maxlen=40, padding='pre')
        preds = model.predict(seq, verbose=0)[0]
        preds = np.log(preds + 1e-8) / temperature
        probs = np.exp(preds) / np.sum(np.exp(preds))
        idx = np.random.choice(len(probs), p=probs)
        word = tokenizer.index_word.get(idx, "")

        # --- 生成が途切れたら補助単語でつなぐ ---
        if not word:
            word = np.random.choice(["検査", "処方", "診断", "フォローアップ"])
        generated.append(word)
        text += " " + word

        # --- 文の節目で強制的に区切る（長文対策） ---
        if i % 20 == 0 and i > 0:
            generated.append("(+30d)")

    # 検査カテゴリを再数値化
    return [restore_value(t) for t in generated]

# === 4. 生成開始 ===
seed = [
    "診断: ICD10:E11 2型糖尿病 (+0d)",
    "検査: HbA1c:高 (+0d)",
    "処方: YJ:1234567 メトホルミン錠 (+0d)"
]

timeline = generate(seed, steps=120, temperature=1.15)

# === 5. 出力 ===
df_out = pd.DataFrame({
    "synthetic_patient_id": [f"SYNTH_{int(time.time()*1000)}"] * len(timeline),
    "event_order": range(1, len(timeline) + 1),
    "event_text": timeline
})
df_out.to_csv("synthetic_events_with_values.csv", index=False, encoding="utf-8-sig")

print(f"💾 synthetic_events_with_values.csv を出力しました（{len(timeline)} 行）。")
print("✅ 自然な長文生成が完了しました。")
