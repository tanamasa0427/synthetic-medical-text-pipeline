# ============================================================
# step3_eventlevel_training.py
# 「1イベント=1トークン」方式の時系列生成モデル
# ============================================================

import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Embedding, GRU, Dense, Dropout, Layer
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.optimizers import Adam
import pickle
import matplotlib.pyplot as plt
import re

print("🧠 Step3: 医療イベント単位での生成モデル学習開始")

# === 1. データ読み込み ===
df = pd.read_csv("pharmacy_events.csv")
df = df.sort_values(["patient_id", "event_date"])

# === 2. イベントを1トークン化 ===
def normalize_event(s):
    s = re.sub(r"YJ:[0-9A-Za-z]+", "薬剤コード", s)
    s = re.sub(r"\(\+\d+d\)", "(+Xd)", s)
    return s.strip()

df["event_token"] = df["event_full"].apply(normalize_event)
patients = df.groupby("patient_id")["event_token"].apply(list)

# === 3. イベント列を作成 ===
corpus = [" ".join(seq) for seq in patients.tolist()]
tokenizer = Tokenizer(lower=False, filters="")
tokenizer.fit_on_texts(corpus)
sequences = tokenizer.texts_to_sequences(corpus)
vocab_size = len(tokenizer.word_index) + 1

# === 4. 次イベント予測データ作成 ===
input_seqs, target_words = [], []
for seq in sequences:
    for i in range(1, len(seq)):
        input_seqs.append(seq[:i])
        target_words.append(seq[i])

max_len = 15
X = pad_sequences(input_seqs, maxlen=max_len, padding="pre")
y = np.array(target_words)

split_idx = int(len(X) * 0.9)
X_train, X_val = X[:split_idx], X[split_idx:]
y_train, y_val = y[:split_idx], y[split_idx:]

print(f"📊 学習データ: {len(X_train)}件, 語彙数: {vocab_size}")

# === 5. Attention層 ===
class ScaledSelfAttention(Layer):
    def __init__(self, units=64, **kwargs):
        super().__init__(**kwargs)
        self.units = units
    def build(self, input_shape):
        self.Wq = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wk = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wv = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
    def call(self, x):
        Q = tf.matmul(x, self.Wq)
        K = tf.matmul(x, self.Wk)
        V = tf.matmul(x, self.Wv)
        scores = tf.matmul(Q, K, transpose_b=True) / tf.sqrt(tf.cast(self.units, tf.float32))
        weights = tf.nn.softmax(scores, axis=-1)
        context = tf.matmul(weights, V)
        return tf.reduce_mean(context, axis=1)

# === 6. モデル構築 ===
def build_model(vocab_size, max_len):
    inp = Input(shape=(max_len,))
    x = Embedding(vocab_size, 128)(inp)
    x = GRU(128, return_sequences=True)(x)
    x = ScaledSelfAttention(128)(x)
    x = Dropout(0.3)(x)
    out = Dense(vocab_size, activation="softmax")(x)
    model = Model(inp, out)
    model.compile(loss="sparse_categorical_crossentropy", optimizer=Adam(1e-3), metrics=["accuracy"])
    return model

model = build_model(vocab_size, max_len)

# === 7. 学習 ===
print("🚀 学習中...")
history = model.fit(
    X_train, y_train,
    validation_data=(X_val, y_val),
    epochs=15,
    batch_size=128,
    callbacks=[EarlyStopping(patience=3, restore_best_weights=True)],
    verbose=1
)

# === 8. 保存 ===
model.save("gru_attention_eventlevel.h5")
with open("tokenizer_eventlevel.pkl", "wb") as f:
    pickle.dump(tokenizer, f)

print("💾 モデル 'gru_attention_eventlevel.h5' と 'tokenizer_eventlevel.pkl' を保存しました。")
