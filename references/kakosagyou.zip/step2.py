import pandas as pd
import numpy as np
import json

print("--- Step2: 病院データ整形 + 検査レンジ自動生成 ---")

# 臨床基準値の既定設定（必要に応じて追加可能）
CLINICAL_THRESHOLDS = {
    "HbA1c": {"low": 5.7, "high": 6.5},
    "LDL-C": {"low": 80, "high": 140},
    "Cr": {"low": 0.6, "high": 1.2},
    "eGFR": {"low": 60, "high": 90},
    "AST": {"low": 10, "high": 40},
    "ALT": {"low": 5, "high": 45},
    "中性脂肪": {"low": 50, "high": 150},
    "尿酸": {"low": 3.0, "high": 7.0},
}

def categorize_value(name, val, low_thr, high_thr):
    """数値→カテゴリ"""
    if pd.isna(val): return "不明"
    if name == "eGFR":
        if val < low_thr: return "低"
        elif val <= high_thr: return "正常"
        else: return "高"
    if val < low_thr: return "低"
    elif val <= high_thr: return "正常"
    return "高"

try:
    # === 1. データ読み込み ===
    df_disease = pd.read_csv("disease.csv")
    df_drug = pd.read_csv("drug.csv")
    df_inspection = pd.read_csv("inspection.csv")

    # === 2. 検査値数値化 ===
    df_inspection["inspection_value"] = pd.to_numeric(
        df_inspection["inspection_value"].astype(str).str.replace(r"[^\d\.\-]", "", regex=True),
        errors="coerce"
    ).fillna(0)
    df_inspection = df_inspection.dropna(subset=["inspection_value"])

    # === 3. 統計集計 ===
    stats = (
        df_inspection.groupby("inspection_name")["inspection_value"]
        .agg(["min", "max", "mean", "std",
              lambda x: x.quantile(0.25),
              lambda x: x.median(),
              lambda x: x.quantile(0.75)])
        .rename(columns={"<lambda_0>": "q1", "<lambda_1>": "median", "<lambda_2>": "q3"})
        .reset_index()
    )

    RANGE_TABLE = {}
    for _, r in stats.iterrows():
        name = r["inspection_name"]
        q1, q3, minv, maxv = r["q1"], r["q3"], r["min"], r["max"]
        if name in CLINICAL_THRESHOLDS:
            low_thr, high_thr = CLINICAL_THRESHOLDS[name]["low"], CLINICAL_THRESHOLDS[name]["high"]
        else:
            low_thr, high_thr = q1, q3
        RANGE_TABLE[name] = {
            "低": [float(minv), float(low_thr)],
            "正常": [float(low_thr), float(high_thr)],
            "高": [float(high_thr), float(maxv)]
        }

    # === 4. カテゴリ付与 ===
    df_inspection["category"] = df_inspection.apply(
        lambda r: categorize_value(r["inspection_name"], r["inspection_value"],
                                   *RANGE_TABLE.get(r["inspection_name"], {"正常":[np.nan, np.nan]})["正常"]),
        axis=1
    )

    # === 5. イベント整形 ===
    df_inspection["event_type"] = "検査"
    df_inspection["event_date"] = pd.to_datetime(df_inspection["inspection_date"], errors="coerce")
    df_inspection["event_detail"] = df_inspection["inspection_name"] + ":" + df_inspection["category"]

    df_disease["event_type"] = "診断"
    df_disease["event_date"] = pd.to_datetime(df_disease["disease_date"], errors="coerce")
    df_disease["event_detail"] = "ICD10:" + df_disease["icd10_code"].astype(str) + " " + df_disease["disease_name"].astype(str)

    df_drug["event_type"] = "処方"
    df_drug["event_date"] = pd.to_datetime(df_drug["key_date"], errors="coerce")
    df_drug["event_detail"] = "YJ:" + df_drug["yj_code"].astype(str) + " " + df_drug["drug_name"].astype(str)

    all_events = pd.concat([df_disease, df_drug, df_inspection])
    all_events = all_events.sort_values(["patient_id", "event_date"])
    all_events["days_since_prev"] = (
        all_events.groupby("patient_id")["event_date"].diff().dt.days.fillna(0).astype(int)
    )

    # === 6. 出力 ===
    all_events.to_csv("all_events.csv", index=False, encoding="utf-8-sig")
    with open("inspection_ranges.json", "w", encoding="utf-8") as f:
        json.dump(RANGE_TABLE, f, ensure_ascii=False, indent=2)

    print("💾 'all_events.csv' & 'inspection_ranges.json' を出力しました。")

except Exception as e:
    print("❌ エラー:", e)
