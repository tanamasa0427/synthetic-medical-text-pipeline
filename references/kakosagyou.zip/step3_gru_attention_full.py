# ============================================================
# step3_gru_attention_full.py
# フルデータ版 GRU + Scaled Self-Attention 転移学習（完全版）
# ============================================================

import os
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Embedding, GRU, Dense, Dropout, Layer
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.callbacks import EarlyStopping
import matplotlib.pyplot as plt
import pickle
import ctypes
import platform
from tqdm import tqdm

# ============================================================
# スリープ防止設定（Windows対応）
# ============================================================
if platform.system() == "Windows":
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000002)
    print("💡 スリープ防止モードを有効化しました。")

# ============================================================
# Scaled Self-Attention層
# ============================================================
class ScaledSelfAttention(Layer):
    def __init__(self, units=64, **kwargs):
        super(ScaledSelfAttention, self).__init__(**kwargs)
        self.units = units

    def build(self, input_shape):
        self.Wq = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wk = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wv = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        super(ScaledSelfAttention, self).build(input_shape)

    def call(self, x):
        Q = tf.matmul(x, self.Wq)
        K = tf.matmul(x, self.Wk)
        V = tf.matmul(x, self.Wv)
        scores = tf.matmul(Q, K, transpose_b=True) / tf.sqrt(tf.cast(self.units, tf.float32))
        weights = tf.nn.softmax(scores, axis=-1)
        context = tf.matmul(weights, V)
        output = tf.reduce_mean(context, axis=1)
        self.last_attention = weights
        return output

# ============================================================
# データ準備
# ============================================================
print("🧠 データ準備中...")

df = pd.read_csv("pharmacy_events.csv")

texts = df["event_full"].astype(str).tolist()
labels = np.random.randint(0, 2, size=len(texts))  # 仮ラベル（二値分類タスク用）

tokenizer = Tokenizer(char_level=False)
tokenizer.fit_on_texts(texts)
sequences = tokenizer.texts_to_sequences(texts)

max_len = 500
vocab_size = len(tokenizer.word_index) + 1
data = pad_sequences(sequences, maxlen=max_len, padding="post")

# === トークナイザ保存 ===
with open("tokenizer_attention.pkl", "wb") as f:
    pickle.dump(tokenizer, f)

# データ分割
split_idx = int(len(data) * 0.8)
X_train, X_val = data[:split_idx], data[split_idx:]
y_train, y_val = labels[:split_idx], labels[split_idx:]

print(f"📊 学習データ数: {len(X_train)}, 検証データ数: {len(X_val)}")
print(f"🧾 語彙数: {vocab_size}, 最大系列長: {max_len}")

# ============================================================
# モデル構築
# ============================================================
def build_attention_gru_model(vocab_size, max_len):
    inputs = Input(shape=(max_len,), name="input_layer")
    x = Embedding(vocab_size, 128, name="embedding")(inputs)
    x = GRU(128, return_sequences=True, name="gru")(x)
    x = ScaledSelfAttention(units=128, name="scaled_attention")(x)
    x = Dropout(0.4)(x)
    outputs = Dense(2, activation="softmax", name="output")(x)
    model = Model(inputs, outputs)
    model.compile(optimizer=Adam(1e-3),
                  loss="sparse_categorical_crossentropy",
                  metrics=["acc"])
    return model

model = build_attention_gru_model(vocab_size, max_len)
model.summary()

# ============================================================
# 学習
# ============================================================
print("🚀 学習開始（全量データ）...")
history = model.fit(
    X_train, y_train,
    validation_data=(X_val, y_val),
    epochs=5,
    batch_size=64,
    callbacks=[EarlyStopping(patience=2, restore_best_weights=True)],
    verbose=1
)

# ============================================================
# 可視化
# ============================================================
plt.figure(figsize=(8, 5))
plt.plot(history.history["loss"], label="訓練Loss")
plt.plot(history.history["val_loss"], "--", label="検証Loss")
plt.plot(history.history["acc"], label="訓練Acc")
plt.plot(history.history["val_acc"], "--", label="検証Acc")
plt.title("学習曲線（全量データ・Scaled Attention版）", fontsize=12)
plt.xlabel("エポック")
plt.ylabel("値")
plt.legend()
plt.tight_layout()
plt.savefig("training_plot_attention_full.png", dpi=200)
plt.close()
print("📈 学習曲線を training_plot_attention_full.png に保存しました。")

# ============================================================
# モデル保存
# ============================================================
model.save("gru_attention_full.h5")
print("💾 モデルとトークナイザを保存しました。")

# ============================================================
# スリープ解除
# ============================================================
if platform.system() == "Windows":
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
    print("🛌 スリープ防止を解除しました。")

print("✅ Attention対応GRUモデル（フルデータ版）の学習が完了しました。")
