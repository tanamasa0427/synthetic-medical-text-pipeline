# ============================================================
# step4_eventlevel_generate_v6.py
# Attention-GRU イベント整形＋1行1薬剤分割＋重複除去
# ============================================================

import tensorflow as tf
import numpy as np
import pickle, json, pandas as pd, re, time, random

print("--- Step4: Attention-GRU 出力最終整形（1行1薬剤）---")

# === カスタムレイヤー ===
from tensorflow.keras.layers import Layer
class ScaledSelfAttention(Layer):
    def __init__(self, units=64, **kwargs):
        super().__init__(**kwargs)
        self.units = units
    def build(self, input_shape):
        self.Wq = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wk = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wv = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
    def call(self, x):
        Q = tf.matmul(x, self.Wq)
        K = tf.matmul(x, self.Wk)
        V = tf.matmul(x, self.Wv)
        scores = tf.matmul(Q, K, transpose_b=True) / tf.sqrt(tf.cast(self.units, tf.float32))
        weights = tf.nn.softmax(scores, axis=-1)
        context = tf.matmul(weights, V)
        return tf.reduce_mean(context, axis=1)

# === モデル・トークナイザ ===
model = tf.keras.models.load_model(
    "gru_attention_eventlevel.h5",
    compile=False,
    custom_objects={"ScaledSelfAttention": ScaledSelfAttention}
)
with open("tokenizer_eventlevel.pkl", "rb") as f:
    tokenizer = pickle.load(f)
with open("inspection_ranges.json", "r", encoding="utf-8") as f:
    RANGE_TABLE = json.load(f)

# === 辞書 ===
DRUG_POOL = [
    "メトホルミン錠 500mg",
    "オゼンピック皮下注 0.25mg",
    "オゼンピック皮下注 0.5mg",
    "アマリール錠 1mg",
    "デベルザ錠 20mg",
    "ジャヌビア錠 50mg",
    "トレシーバ注 フレックスタッチ",
    "ヒューマログ注 ミリオペン"
]

# === (+Xd)展開 ===
def expand_days(event):
    if "(+Xd)" not in event:
        return event
    d = random.choice([7, 14, 30, 60, 90])
    return event.replace("(+Xd)", f"(+{d}d)")

# === 生成 ===
def generate(seed, steps=60, temperature=1.1):
    text = " ".join(seed)
    out = seed.copy()
    for _ in range(steps):
        seq = tokenizer.texts_to_sequences([text])
        seq = tf.keras.preprocessing.sequence.pad_sequences(seq, maxlen=15, padding='pre')
        preds = model.predict(seq, verbose=0)[0]
        preds = np.log(preds + 1e-8) / temperature
        probs = np.exp(preds) / np.sum(np.exp(preds))
        idx = np.random.choice(len(probs), p=probs)
        word = tokenizer.index_word.get(idx, "")
        if not word or len(word) < 2:
            continue
        out.append(word)
        text += " " + word
    return [expand_days(t) for t in out]

# === イベント整形 ===
def split_drugs(event_text):
    """
    1行に複数薬剤がある場合、正規表現で分割してリストで返す。
    """
    # 薬剤名パターン（錠、カプセル、注、OD、皮下注などをキーワード化）
    pattern = r"(メトホルミン錠|デベルザ錠|アマリール錠|オゼンピック皮下注|トレシーバ注|ジャヌビア錠|ヒューマログ注|フェノフィブラート錠|ランタス|テルミサルタン錠|パリエット錠|グリクラジド錠|フォシーガ錠|ロキソプロフェンナトリウム錠|エゼチミブ錠)"
    parts = re.split(f"(?={pattern})", event_text)
    return [p.strip() for p in parts if len(p.strip()) > 0]

def postprocess_events(tokens):
    events, buf = [], ""
    for t in tokens:
        if re.match(r"^(診断|検査|処方|フォローアップ)", t):
            if buf:
                events.append(buf.strip())
            buf = t
        elif len(t.strip()) > 0:
            buf += " " + t
    if buf:
        events.append(buf.strip())

    clean = []
    for e in events:
        e = e.strip()

        # 薬剤コード置換
        if "薬剤コード" in e:
            e = e.replace("薬剤コード", random.choice(DRUG_POOL))

        # 無効行削除
        if re.fullmatch(r"処方[:：]?\s*\(\+\d+d\)", e):
            continue
        if e in ["処方:", "処方: (+Xd)"]:
            continue

        clean.append(e)

    # (+Xd)の結合
    merged = []
    for e in clean:
        if re.fullmatch(r"\(\+\d+d\)", e) and merged:
            merged[-1] += " " + e
        elif re.match(r"^処方:\s*\(\+\d+d\)", e) and merged:
            day = re.findall(r"\(\+\d+d\)", e)
            if day:
                merged[-1] += " " + day[0]
        else:
            merged.append(e)

    # 1行に複数薬剤がある場合は分割
    final = []
    for e in merged:
        if e.startswith("処方:"):
            drugs = split_drugs(e)
            for d in drugs:
                if not d.startswith("処方:"):
                    d = "処方: " + d
                final.append(d)
        else:
            final.append(e)

    # 重複除去
    uniq = []
    for e in final:
        if not uniq or e != uniq[-1]:
            uniq.append(e)
    return uniq

# === シード ===
seed = [
    "診断: ICD10:E11 2型糖尿病 (+0d)",
    "検査: HbA1c:高 (+0d)",
    "処方: メトホルミン錠 (+Xd)"
]

# === 実行 ===
raw = generate(seed)
structured = postprocess_events(raw)

# === 出力 ===
df = pd.DataFrame({
    "synthetic_patient_id": [f"SYNTH_{int(time.time()*1000)}"] * len(structured),
    "event_order": range(1, len(structured) + 1),
    "event_text": structured
})
df.to_csv("synthetic_events_split.csv", index=False, encoding="utf-8-sig")

print(f"💾 synthetic_events_split.csv を出力しました（{len(structured)} 行）。")
