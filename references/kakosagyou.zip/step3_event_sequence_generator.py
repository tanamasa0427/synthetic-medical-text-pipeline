# ============================================================
# step3_event_sequence_generator.py
# 医療イベント単位での時系列生成モデル（Attention-GRU）
# ============================================================

import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Embedding, GRU, Dense, Dropout, Layer
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.optimizers import Adam
import pickle
import matplotlib.pyplot as plt
import re
import platform, ctypes

print("🧠 Step3: イベント単位生成モデルの学習を開始します...")

# ============================================================
# 0. Windowsスリープ防止
# ============================================================
if platform.system() == "Windows":
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000002)

# ============================================================
# 1. データ読み込み
# ============================================================
df = pd.read_csv("pharmacy_events.csv")

# 各患者のイベントを時系列順に並べ、event_fullを使う
df = df.sort_values(["patient_id", "event_date"])
events = df.groupby("patient_id")["event_full"].apply(list)

# ============================================================
# 2. イベント単位トークナイズ準備
# ============================================================
print("📘 イベント単位の系列を整形中...")

# 各患者のイベント系列を文字列化（空白区切り）
corpus = [" ".join(seq) for seq in events.tolist()]

# トークナイザを「単語」ではなく「イベント単位」で扱う
tokenizer = Tokenizer(lower=False, filters="")
tokenizer.fit_on_texts(corpus)
sequences = tokenizer.texts_to_sequences(corpus)
vocab_size = len(tokenizer.word_index) + 1

# ============================================================
# 3. 学習データ生成（次イベント予測）
# ============================================================
input_seqs = []
target_words = []

for seq in sequences:
    for i in range(1, len(seq)):
        input_seqs.append(seq[:i])
        target_words.append(seq[i])

max_len = 20
X = pad_sequences(input_seqs, maxlen=max_len, padding="pre")
y = np.array(target_words)

split_idx = int(len(X) * 0.9)
X_train, X_val = X[:split_idx], X[split_idx:]
y_train, y_val = y[:split_idx], y[split_idx:]

print(f"📊 データ件数: {len(X_train)} (train), 語彙数: {vocab_size}")

# ============================================================
# 4. Attention層定義
# ============================================================
class ScaledSelfAttention(Layer):
    def __init__(self, units=64, **kwargs):
        super().__init__(**kwargs)
        self.units = units

    def build(self, input_shape):
        self.Wq = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wk = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wv = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        super().build(input_shape)

    def call(self, x):
        Q = tf.matmul(x, self.Wq)
        K = tf.matmul(x, self.Wk)
        V = tf.matmul(x, self.Wv)
        scores = tf.matmul(Q, K, transpose_b=True) / tf.sqrt(tf.cast(self.units, tf.float32))
        weights = tf.nn.softmax(scores, axis=-1)
        context = tf.matmul(weights, V)
        return tf.reduce_mean(context, axis=1)

# ============================================================
# 5. モデル構築
# ============================================================
def build_model(vocab_size, max_len):
    inp = Input(shape=(max_len,))
    x = Embedding(vocab_size, 128)(inp)
    x = GRU(128, return_sequences=True)(x)
    x = ScaledSelfAttention(128)(x)
    x = Dropout(0.3)(x)
    out = Dense(vocab_size, activation="softmax")(x)
    model = Model(inp, out)
    model.compile(loss="sparse_categorical_crossentropy", optimizer=Adam(1e-3), metrics=["accuracy"])
    return model

model = build_model(vocab_size, max_len)
model.summary()

# ============================================================
# 6. 学習
# ============================================================
print("🚀 モデル学習中...")
history = model.fit(
    X_train, y_train,
    validation_data=(X_val, y_val),
    epochs=15,
    batch_size=128,
    callbacks=[EarlyStopping(patience=3, restore_best_weights=True)],
    verbose=1
)

plt.plot(history.history["loss"], label="train")
plt.plot(history.history["val_loss"], "--", label="val")
plt.legend(); plt.title("Loss Curve"); plt.tight_layout()
plt.savefig("training_plot_event_seq.png", dpi=200)
plt.close()

# ============================================================
# 7. 保存
# ============================================================
model.save("gru_attention_eventseq.h5")
with open("tokenizer_eventseq.pkl", "wb") as f:
    pickle.dump(tokenizer, f)

print("💾 モデル 'gru_attention_eventseq.h5' とトークナイザ 'tokenizer_eventseq.pkl' を保存しました。")
print("✅ Step3（イベント単位モデル）完了！")

if platform.system() == "Windows":
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
