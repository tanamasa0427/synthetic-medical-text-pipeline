# ============================================================
# step4_eventlevel_generate_v3.py
# イベント単位 Attention-GRU + 処方分割 + 構文整理
# ============================================================

import tensorflow as tf
import numpy as np
import pickle, json, pandas as pd, re, time, random

print("--- Step4: 処方分割＆整形強化版 ---")

# === カスタムレイヤー定義 ===
from tensorflow.keras.layers import Layer
class ScaledSelfAttention(Layer):
    def __init__(self, units=64, **kwargs):
        super().__init__(**kwargs)
        self.units = units
    def build(self, input_shape):
        self.Wq = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wk = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wv = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
    def call(self, x):
        Q = tf.matmul(x, self.Wq)
        K = tf.matmul(x, self.Wk)
        V = tf.matmul(x, self.Wv)
        scores = tf.matmul(Q, K, transpose_b=True) / tf.sqrt(tf.cast(self.units, tf.float32))
        weights = tf.nn.softmax(scores, axis=-1)
        context = tf.matmul(weights, V)
        return tf.reduce_mean(context, axis=1)

# === モデル・トークナイザ読込 ===
model = tf.keras.models.load_model(
    "gru_attention_eventlevel.h5",
    compile=False,
    custom_objects={"ScaledSelfAttention": ScaledSelfAttention}
)
with open("tokenizer_eventlevel.pkl", "rb") as f:
    tokenizer = pickle.load(f)
with open("inspection_ranges.json", "r", encoding="utf-8") as f:
    RANGE_TABLE = json.load(f)

# === 薬剤辞書 ===
DRUG_POOL = [
    "メトホルミン錠 500mg",
    "オゼンピック皮下注 0.25mg",
    "オゼンピック皮下注 0.5mg",
    "グリメピリド錠 1mg",
    "ケレンディア錠 10mg",
    "アマリール錠 1mg",
    "デベルザ錠 20mg",
    "ジャヌビア錠 50mg",
    "トレシーバ注 ペンフィル"
]

def replace_drug_placeholders(text):
    return re.sub(r"薬剤コード", random.choice(DRUG_POOL), text)

# === 検査カテゴリ→数値 ===
def sample_from_range(name, cat):
    if name not in RANGE_TABLE or cat not in RANGE_TABLE[name]:
        return np.nan
    low, high = RANGE_TABLE[name][cat]
    if np.isnan(low) or np.isnan(high) or low >= high:
        return np.nan
    mean, std = (low + high) / 2, (high - low) / 6
    val = np.random.normal(mean, std)
    return round(float(np.clip(val, low, high)), 1)

def restore_lab_value(event):
    m = re.search(r"検査[:：]\s*([A-Za-z0-9一-龥\-]+)\s*[:：]\s*(低|正常|高)", event)
    if not m:
        return event
    name, cat = m.groups()
    val = sample_from_range(name, cat)
    return f"検査: {name}:{val}"

# === (+Xd)展開 ===
def expand_days(event):
    if "(+Xd)" not in event:
        return event
    d = random.choice([7, 14, 30, 60, 90])
    return event.replace("(+Xd)", f"(+{d}d)")

# === 生成 ===
def generate(seed, steps=60, temperature=1.15):
    text = " ".join(seed)
    out = seed.copy()
    for _ in range(steps):
        seq = tokenizer.texts_to_sequences([text])
        seq = tf.keras.preprocessing.sequence.pad_sequences(seq, maxlen=15, padding='pre')
        preds = model.predict(seq, verbose=0)[0]
        preds = np.log(preds + 1e-8) / temperature
        probs = np.exp(preds) / np.sum(np.exp(preds))
        idx = np.random.choice(len(probs), p=probs)
        word = tokenizer.index_word.get(idx, "")
        if not word or len(word) < 2:
            continue
        out.append(word)
        text += " " + word
    out = [expand_days(restore_lab_value(replace_drug_placeholders(t))) for t in out]
    return out

# === イベント整形 ===
def postprocess_events(tokens):
    """イベント単位整形＋処方分割"""
    events, buf = [], ""
    for t in tokens:
        if re.match(r"^(診断|検査|処方|フォローアップ)", t):
            if buf:
                events.append(buf.strip())
            buf = t
        elif len(t.strip()) > 0:
            buf += " " + t
    if buf:
        events.append(buf.strip())

    cleaned = []
    for e in events:
        e = e.strip()
        if re.fullmatch(r"処方[:：]?$", e):  # 空処方削除
            continue
        # 処方行を薬剤単位に分割
        if e.startswith("処方:"):
            parts = re.split(r"\s(?=[ァ-ヶA-Za-z0-9一-龥])", e[3:].strip())
            for p in parts:
                p = p.strip()
                if len(p) > 2 and not p.startswith("(+"):
                    cleaned.append("処方: " + p)
        else:
            cleaned.append(e)
    # (+Xd)が孤立している場合は直前イベントに結合
    merged = []
    for e in cleaned:
        if re.fullmatch(r"\(\+\d+d\)", e) and merged:
            merged[-1] += " " + e
        else:
            merged.append(e)
    # 重複除去
    final = []
    for e in merged:
        if not final or e != final[-1]:
            final.append(e)
    return final

# === シード ===
seed = [
    "診断: ICD10:E11 2型糖尿病 (+0d)",
    "検査: HbA1c:高 (+0d)",
    "処方: 薬剤コード (+Xd)"
]

# === 実行 ===
raw = generate(seed)
structured = postprocess_events(raw)

# === 出力 ===
df = pd.DataFrame({
    "synthetic_patient_id": [f"SYNTH_{int(time.time()*1000)}"] * len(structured),
    "event_order": range(1, len(structured) + 1),
    "event_text": structured
})
df.to_csv("synthetic_events_cleaned.csv", index=False, encoding="utf-8-sig")

print(f"💾 synthetic_events_cleaned.csv を出力しました（{len(structured)} 行）。")
