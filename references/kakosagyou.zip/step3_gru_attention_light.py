# step3_gru_attention_light.py
import os
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import (
    Input, Embedding, GRU, Dense, Dropout, Layer
)
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.callbacks import EarlyStopping
import matplotlib.pyplot as plt
import seaborn as sns
import pickle
import ctypes
import platform

# === Windowsスリープ防止 ===
if platform.system() == "Windows":
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000002)
    print("💡 スリープ防止モードを有効化しました。")

print("--- Step3: 軽量GRU + Attention 転移学習（学習対応完全版） ---")

# === SelfAttention層の定義 ===
class SelfAttention(Layer):
    def __init__(self, **kwargs):
        super(SelfAttention, self).__init__(**kwargs)

    def build(self, input_shape):
        self.W = self.add_weight(
            name="att_weight",
            shape=(input_shape[-1], 1),
            initializer="glorot_uniform",
            trainable=True
        )
        self.b = self.add_weight(
            name="att_bias",
            shape=(1,),
            initializer="zeros",
            trainable=True
        )
        super(SelfAttention, self).build(input_shape)

    def call(self, x):
        # 各タイムステップごとにスコアを算出
        e = tf.keras.activations.tanh(tf.matmul(x, self.W) + self.b)
        a = tf.nn.softmax(e, axis=1)  # 正規化された注意重み
        output = tf.reduce_sum(x * a, axis=1)
        return output

# === データ準備 ===
df = pd.read_csv("pharmacy_events.csv")
texts = df["event_full"].astype(str).tolist()

tokenizer = Tokenizer(char_level=False)
tokenizer.fit_on_texts(texts)
sequences = tokenizer.texts_to_sequences(texts)

max_len = 500
vocab_size = len(tokenizer.word_index) + 1
data = pad_sequences(sequences, maxlen=max_len, padding="post")

labels = np.random.randint(0, 2, size=len(data))  # ダミー二値分類（例）

# === トークナイザ保存 ===
with open("tokenizer_attention.pkl", "wb") as f:
    pickle.dump(tokenizer, f)

# === モデル定義 ===
def build_attention_gru_model(vocab_size, max_len):
    inputs = Input(shape=(max_len,))
    emb = Embedding(vocab_size, 64)(inputs)
    x = GRU(64, return_sequences=True)(emb)  # ★ Attention対応
    x = SelfAttention()(x)
    x = Dropout(0.3)(x)
    outputs = Dense(2, activation="softmax")(x)
    model = Model(inputs, outputs)
    model.compile(
        optimizer=Adam(1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["acc"]
    )
    return model

# === モデル作成 ===
model = build_attention_gru_model(vocab_size, max_len)
model.summary()

# === 学習（事前学習相当）===
history = model.fit(
    data,
    labels,
    epochs=3,
    batch_size=8,
    validation_split=0.2,
    callbacks=[EarlyStopping(patience=2, restore_best_weights=True)],
    verbose=1
)

# === 結果可視化 ===
plt.figure(figsize=(8, 4))
plt.plot(history.history["loss"], label="訓練Loss")
plt.plot(history.history["val_loss"], label="検証Loss", linestyle="--")
plt.plot(history.history["acc"], label="訓練Acc")
plt.plot(history.history["val_acc"], label="検証Acc", linestyle="--")
plt.title("学習曲線（損失・精度・Attention対応版）")
plt.xlabel("エポック")
plt.ylabel("値")
plt.legend()
plt.tight_layout()
plt.savefig("training_plot_attention_fixed.png")
plt.close()

# === 保存 ===
model.save("gru_attention_light.h5")
print("💾 モデルとトークナイザを保存しました。")

# === スリープ防止解除 ===
if platform.system() == "Windows":
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
    print("🛌 スリープ防止を解除しました。")

print("✅ Attention対応版GRUモデルの学習が完了しました。")
