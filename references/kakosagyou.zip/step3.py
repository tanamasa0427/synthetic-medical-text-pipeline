# ===============================================
# Step3: 調剤→病院 転移学習（スリープ防止 + 進捗バー付き）
# ===============================================
import ctypes
import time
import pandas as pd, numpy as np, tensorflow as tf, pickle
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Bidirectional
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tqdm import tqdm  # ← 進捗バー用

# === スリープ防止設定（Windows） ===
try:
    ES_CONTINUOUS = 0x80000000
    ES_SYSTEM_REQUIRED = 0x00000001
    ES_DISPLAY_REQUIRED = 0x00000002
    ctypes.windll.kernel32.SetThreadExecutionState(
        ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
    )
    print("💡 スリープ防止モードを有効化しました。")
except Exception as e:
    print("⚠️ スリープ防止設定に失敗しました:", e)

print("\n--- Step3: 調剤→病院 転移学習 ---")

# === 1. データ読み込み ===
print("📂 データ読み込み中...")
pharm = pd.read_csv("pharmacy_events.csv")
hosp = pd.read_csv("all_events.csv")

pharm_text = pharm.groupby("patient_id")["event_full"].apply(list)
hosp_text = hosp.groupby("patient_id")["event_detail"].apply(list)

# === 2. トークナイザ構築 ===
print("🔤 トークナイザ構築中...")
tokenizer = Tokenizer(filters='', lower=False, split=' ')
tokenizer.fit_on_texts(pharm_text.apply(" ".join).tolist() + hosp_text.apply(" ".join).tolist())
vocab_size = len(tokenizer.word_index) + 1
print(f"📚 語彙サイズ: {vocab_size:,}")

# === ユーティリティ関数 ===
def build_xy(seqs):
    X, y = [], []
    for seq in tqdm(seqs, desc="🔧 シーケンス構築中", ncols=80):
        for i in range(1, len(seq)):
            X.append(seq[:i]); y.append(seq[i])
    return X, y

def pad_xy(X, y):
    max_len = max(map(len, X))
    return pad_sequences(X, maxlen=max_len, padding='pre'), np.array(y), max_len

# === 3. 調剤データで事前学習 ===
print("\n🧠 調剤データで事前学習（20エポック）")
pharm_seq = tokenizer.texts_to_sequences(pharm_text.apply(" ".join))
X_p, y_p = build_xy(pharm_seq)
X_p, y_p, max_len = pad_xy(X_p, y_p)

model = Sequential([
    Embedding(vocab_size, 128, input_length=max_len),
    Bidirectional(LSTM(150, return_sequences=True)),
    Bidirectional(LSTM(150)),
    Dense(vocab_size, activation='softmax')
])
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy')

# 学習時間測定
start_time = time.time()
hist1 = model.fit(X_p, y_p, epochs=20, verbose=1)
elapsed1 = time.time() - start_time
print(f"⏱️ 調剤データ学習完了（経過時間: {elapsed1/60:.1f}分）")

# === 4. 病院データで転移学習 ===
print("\n🏥 病院データで転移学習（5エポック）")
hosp_seq = tokenizer.texts_to_sequences(hosp_text.apply(" ".join))
X_h, y_h = build_xy(hosp_seq)
X_h, y_h, _ = pad_xy(X_h, y_h)

start_time = time.time()
hist2 = model.fit(X_h, y_h, epochs=5, verbose=1)
elapsed2 = time.time() - start_time
print(f"⏱️ 病院データ転移学習完了（経過時間: {elapsed2/60:.1f}分）")

# === 5. モデル保存 ===
model.save("lstm_model_transfer.h5")
with open("tokenizer_transfer.pkl", "wb") as f:
    pickle.dump(tokenizer, f)
print("💾 モデルとトークナイザを保存しました。")

# === スリープ防止を解除 ===
try:
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
    print("🛌 スリープ防止を解除しました。")
except Exception as e:
    print("⚠️ スリープ解除に失敗しました:", e)

# === サマリー表示 ===
total_time = (elapsed1 + elapsed2) / 60
print("\n✅ Step3 完了")
print(f"🕒 総実行時間（推定）: {total_time:.1f} 分")
