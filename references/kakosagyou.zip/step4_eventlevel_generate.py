# ============================================================
# step4_eventlevel_generate.py
# Attention-GRU（イベント単位）生成モデル + 薬剤名・検査値復元
# ============================================================

import tensorflow as tf
import numpy as np
import pickle, json, pandas as pd, re, time, random

print("--- Step4: イベント単位 Attention-GRU による生成 + 薬剤名復元 ---")

# === 0. カスタムレイヤー定義 ===
from tensorflow.keras.layers import Layer

class ScaledSelfAttention(Layer):
    def __init__(self, units=64, **kwargs):
        super().__init__(**kwargs)
        self.units = units

    def build(self, input_shape):
        self.Wq = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wk = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wv = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        super().build(input_shape)

    def call(self, x):
        Q = tf.matmul(x, self.Wq)
        K = tf.matmul(x, self.Wk)
        V = tf.matmul(x, self.Wv)
        scores = tf.matmul(Q, K, transpose_b=True) / tf.sqrt(tf.cast(self.units, tf.float32))
        weights = tf.nn.softmax(scores, axis=-1)
        context = tf.matmul(weights, V)
        return tf.reduce_mean(context, axis=1)

# === 1. モデル・トークナイザ・検査レンジ読込 ===
model = tf.keras.models.load_model(
    "gru_attention_eventlevel.h5",
    compile=False,
    custom_objects={"ScaledSelfAttention": ScaledSelfAttention}
)
with open("tokenizer_eventlevel.pkl", "rb") as f:
    tokenizer = pickle.load(f)
with open("inspection_ranges.json", "r", encoding="utf-8") as f:
    RANGE_TABLE = json.load(f)

# === 2. 薬剤辞書（復元マップ） ===
# 代表的な糖尿病関連薬剤
DRUG_MAP = {
    "薬剤コード": random.choice([
        "メトホルミン錠 500mg",
        "オゼンピック皮下注 0.25mg",
        "オゼンピック皮下注 0.5mg",
        "グリメピリド錠 1mg",
        "ジャヌビア錠 50mg",
        "ケレンディア錠 10mg"
    ]),
    "スタチン": random.choice([
        "ピタバスタチンCa錠 2mg",
        "ロスバスタチン錠 5mg"
    ]),
}

def replace_drug_placeholders(text):
    for key, val in DRUG_MAP.items():
        text = text.replace(key, val)
    return text

# === 3. 検査値カテゴリ→数値変換 ===
def sample_from_range(name, cat):
    if name not in RANGE_TABLE or cat not in RANGE_TABLE[name]:
        return np.nan
    low, high = RANGE_TABLE[name][cat]
    if np.isnan(low) or np.isnan(high) or low >= high:
        return np.nan
    mean, std = (low + high) / 2, (high - low) / 6
    val = np.random.normal(mean, std)
    return round(float(np.clip(val, low, high)), 1)

def restore_lab_value(event):
    m = re.search(r"検査[:：]\s*([A-Za-z0-9一-龥\-]+)\s*[:：]\s*(低|正常|高)", event)
    if not m:
        return event
    name, cat = m.groups()
    val = sample_from_range(name, cat)
    return f"検査: {name}:{val}"

# === 4. (+Xd) の展開 ===
def expand_days(event):
    if "(+Xd)" not in event:
        return event
    day = random.choice([7, 14, 30, 60, 90])
    return event.replace("(+Xd)", f"(+{day}d)")

# === 5. 生成関数 ===
def generate_event_sequence(seed, steps=30, temperature=1.1):
    current_seq = " ".join(seed)
    generated = seed.copy()

    for _ in range(steps):
        seq = tokenizer.texts_to_sequences([current_seq])
        seq = tf.keras.preprocessing.sequence.pad_sequences(seq, maxlen=15, padding="pre")
        preds = model.predict(seq, verbose=0)[0]
        preds = np.log(preds + 1e-8) / temperature
        probs = np.exp(preds) / np.sum(np.exp(preds))
        idx = np.random.choice(len(probs), p=probs)
        next_word = tokenizer.index_word.get(idx, "")

        if not next_word or len(next_word) < 3:
            continue

        generated.append(next_word)
        current_seq += " " + next_word

    # 復元処理
    generated = [replace_drug_placeholders(ev) for ev in generated]
    generated = [restore_lab_value(ev) for ev in generated]
    generated = [expand_days(ev) for ev in generated]
    return generated

# === 6. シード（糖尿病患者） ===
seed = [
    "診断: ICD10:E11 2型糖尿病 (+0d)",
    "検査: HbA1c:高 (+0d)",
    "処方: 薬剤コード (+Xd)"
]

# === 7. 生成 ===
timeline = generate_event_sequence(seed, steps=40, temperature=1.1)

# === 8. 出力 ===
df_out = pd.DataFrame({
    "synthetic_patient_id": [f"SYNTH_{int(time.time()*1000)}"] * len(timeline),
    "event_order": range(1, len(timeline) + 1),
    "event_text": timeline
})
df_out.to_csv("synthetic_events_with_drugnames.csv", index=False, encoding="utf-8-sig")

print(f"💾 synthetic_events_with_drugnames.csv を出力しました（{len(timeline)} イベント）。")
print("✅ 薬剤名復元付きイベント生成が完了しました。")
