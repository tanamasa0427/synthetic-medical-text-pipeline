# ===============================================
# step3_gru_attention_scaled_light.py
# 軽量GRU + Scaled Self-Attention 転移学習（フォント警告対応版）
# ===============================================

import os
import json
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
import tensorflow as tf
from keras.models import Model
from keras.layers import Input, Embedding, GRU, Dense, Dropout, Layer
from keras.optimizers import Adam
from keras.preprocessing.sequence import pad_sequences
import matplotlib
matplotlib.rcParams['font.family'] = 'Meiryo'  # 日本語フォント（Windows向け）

# ---------- スリープ防止 ----------
import ctypes
def prevent_sleep():
    try:
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000002)
        print("💡 スリープ防止モードを有効化しました。")
    except:
        pass

def allow_sleep():
    try:
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        print("🛌 スリープ防止を解除しました。")
    except:
        pass

# ---------- Scaled Self-Attention 層 ----------
class ScaledSelfAttention(Layer):
    def __init__(self, units=64, **kwargs):
        super(ScaledSelfAttention, self).__init__(**kwargs)
        self.units = units

    def build(self, input_shape):
        self.Wq = self.add_weight(shape=(input_shape[-1], self.units), initializer="glorot_uniform", trainable=True)
        self.Wk = self.add_weight(shape=(input_shape[-1], self.units), initializer="glorot_uniform", trainable=True)
        self.Wv = self.add_weight(shape=(input_shape[-1], self.units), initializer="glorot_uniform", trainable=True)
        super(ScaledSelfAttention, self).build(input_shape)

    def call(self, x):
        Q = tf.matmul(x, self.Wq)
        K = tf.matmul(x, self.Wk)
        V = tf.matmul(x, self.Wv)

        # スケーリング付きスコア計算
        scores = tf.matmul(Q, K, transpose_b=True) / tf.sqrt(tf.cast(self.units, tf.float32))
        weights = tf.nn.softmax(scores, axis=-1)

        # コンテキスト計算
        context = tf.matmul(weights, V)

        # 最終的な出力は系列平均
        output = tf.reduce_mean(context, axis=1)

        # Attention可視化用にweights全体を保存（系列長×系列長）
        self.last_attention = weights
        return output


# ---------- データ読み込み ----------
def load_data():
    print("🧠 データ準備中...")
    X = np.random.randint(1, 2000, (500, 500))
    y = np.random.randint(0, 2, 500)
    X_train, X_val = X[:450], X[450:]
    y_train, y_val = y[:450], y[450:]
    vocab_size = 2000
    max_len = 500
    return (X_train, y_train), (X_val, y_val), vocab_size, max_len

# ---------- モデル構築 ----------
def build_attention_gru_model(vocab_size, max_len):
    inp = Input(shape=(max_len,), name="input_layer")
    emb = Embedding(vocab_size, 64, name="embedding")(inp)
    x = GRU(64, return_sequences=True, name="gru")(emb)
    x = ScaledSelfAttention(units=64, name="scaled_attention")(x)
    x = Dropout(0.3)(x)
    out = Dense(2, activation="softmax", name="dense")(x)
    model = Model(inputs=inp, outputs=out)
    return model

# ---------- メイントレーニング ----------
if __name__ == "__main__":
    prevent_sleep()
    print("--- Step3: 軽量GRU + Scaled Attention 転移学習（学習対応完全版） ---")

    (X_train, y_train), (X_val, y_val), vocab_size, max_len = load_data()

    model = build_attention_gru_model(vocab_size, max_len)
    model.compile(optimizer=Adam(1e-3), loss="sparse_categorical_crossentropy", metrics=["acc"])

    model.summary()

    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=3,
        batch_size=32
    )

    # ---------- 学習曲線可視化 ----------
    plt.figure(figsize=(8, 5))
    plt.plot(history.history['loss'], label='訓練Loss')
    plt.plot(history.history['val_loss'], '--', label='検証Loss')
    plt.plot(history.history['acc'], label='訓練Acc')
    plt.plot(history.history['val_acc'], '--', label='検証Acc')
    plt.xlabel('エポック')
    plt.ylabel('値')
    plt.legend()
    plt.title('学習曲線（損失・精度・Scaled Attention版）')
    plt.tight_layout()
    plt.savefig("training_plot_scaled.png")
    print("📈 学習曲線を training_plot_scaled.png に保存しました。")

    # ---------- 保存 ----------
    model.save("gru_attention_scaled_light.h5")
    print("💾 モデルを保存しました。")

    allow_sleep()
    print("✅ Scaled Attention対応Light版GRUモデルの学習が完了しました。")
