# ============================================================
# step3_gru_attention_generate.py
# GRU + Scaled Self-Attention による「次イベント予測」モデル
# ============================================================

import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Embedding, GRU, Dense, Dropout, Layer
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping
import pickle
import matplotlib.pyplot as plt
import platform, ctypes

# ------------------------------------------------------------
# スリープ防止（Windows用）
# ------------------------------------------------------------
if platform.system() == "Windows":
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000002)

print("🧠 Step3（生成タスク）: データ準備中...")

# === データ読み込み ===
df = pd.read_csv("pharmacy_events.csv")
texts = df["event_full"].astype(str).tolist()

# ------------------------------------------------------------
# トークナイズ
# ------------------------------------------------------------
tokenizer = Tokenizer(char_level=False)
tokenizer.fit_on_texts(texts)
sequences = tokenizer.texts_to_sequences(texts)
vocab_size = len(tokenizer.word_index) + 1
max_len = 40  # 各文の長さを短めに調整

# === シーケンスから (X, y) を生成 ===
input_seqs = []
target_words = []

for seq in sequences:
    for i in range(1, len(seq)):
        input_seqs.append(seq[:i])
        target_words.append(seq[i])

X = pad_sequences(input_seqs, maxlen=max_len, padding='pre')
y = np.array(target_words)

# データ分割
split_idx = int(len(X) * 0.9)
X_train, X_val = X[:split_idx], X[split_idx:]
y_train, y_val = y[:split_idx], y[split_idx:]

print(f"📊 学習データ数: {len(X_train)}, 語彙数: {vocab_size}")

# ------------------------------------------------------------
# Scaled Self-Attention 定義
# ------------------------------------------------------------
class ScaledSelfAttention(Layer):
    def __init__(self, units=64, **kwargs):
        super(ScaledSelfAttention, self).__init__(**kwargs)
        self.units = units

    def build(self, input_shape):
        self.Wq = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wk = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wv = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        super().build(input_shape)

    def call(self, x):
        Q = tf.matmul(x, self.Wq)
        K = tf.matmul(x, self.Wk)
        V = tf.matmul(x, self.Wv)
        scores = tf.matmul(Q, K, transpose_b=True) / tf.sqrt(tf.cast(self.units, tf.float32))
        weights = tf.nn.softmax(scores, axis=-1)
        context = tf.matmul(weights, V)
        return tf.reduce_mean(context, axis=1)

# ------------------------------------------------------------
# モデル構築
# ------------------------------------------------------------
def build_model(vocab_size, max_len):
    inputs = Input(shape=(max_len,))
    x = Embedding(vocab_size, 128)(inputs)
    x = GRU(128, return_sequences=True)(x)
    x = ScaledSelfAttention(128)(x)
    x = Dropout(0.3)(x)
    outputs = Dense(vocab_size, activation="softmax")(x)
    model = Model(inputs, outputs)
    model.compile(loss="sparse_categorical_crossentropy", optimizer=Adam(1e-3), metrics=["accuracy"])
    return model

model = build_model(vocab_size, max_len)
model.summary()

# ------------------------------------------------------------
# 学習
# ------------------------------------------------------------
print("🚀 学習開始...")
history = model.fit(
    X_train, y_train,
    validation_data=(X_val, y_val),
    epochs=10,
    batch_size=128,
    callbacks=[EarlyStopping(patience=2, restore_best_weights=True)],
    verbose=1
)

# ------------------------------------------------------------
# 結果表示
# ------------------------------------------------------------
plt.plot(history.history["loss"], label="train")
plt.plot(history.history["val_loss"], "--", label="val")
plt.legend(); plt.title("Loss Curve"); plt.tight_layout()
plt.savefig("training_plot_generate.png", dpi=200)
plt.close()

# ------------------------------------------------------------
# 保存
# ------------------------------------------------------------
model.save("gru_attention_gen.h5")
with open("tokenizer_attention_gen.pkl", "wb") as f:
    pickle.dump(tokenizer, f)

print("💾 モデル: gru_attention_gen.h5 / トークナイザ: tokenizer_attention_gen.pkl を保存しました。")
print("✅ Step3（生成モデル）完了！")

if platform.system() == "Windows":
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
