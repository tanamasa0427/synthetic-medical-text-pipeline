# ============================================================
# step4_from_gru.py（修正版）
# Attention-GRU モデル + 検査値再数値化
# ============================================================

import tensorflow as tf
import numpy as np
import pickle, json, re, pandas as pd, time

print("--- Step4: Attention-GRU モデルによる生成 + 検査値再数値化 ---")

# === 0. カスタムレイヤー定義 ===
from tensorflow.keras.layers import Layer

class ScaledSelfAttention(Layer):
    def __init__(self, units=64, **kwargs):
        super(ScaledSelfAttention, self).__init__(**kwargs)
        self.units = units

    def build(self, input_shape):
        self.Wq = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wk = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        self.Wv = self.add_weight(shape=(input_shape[-1], self.units),
                                  initializer="glorot_uniform", trainable=True)
        super(ScaledSelfAttention, self).build(input_shape)

    def call(self, x):
        Q = tf.matmul(x, self.Wq)
        K = tf.matmul(x, self.Wk)
        V = tf.matmul(x, self.Wv)
        scores = tf.matmul(Q, K, transpose_b=True) / tf.sqrt(tf.cast(self.units, tf.float32))
        weights = tf.nn.softmax(scores, axis=-1)
        context = tf.matmul(weights, V)
        output = tf.reduce_mean(context, axis=1)
        return output

# === 1. モデル・トークナイザ・レンジ読込 ===
model = tf.keras.models.load_model(
    "gru_attention_full.h5",
    compile=False,
    custom_objects={"ScaledSelfAttention": ScaledSelfAttention}
)
with open("tokenizer_attention.pkl", "rb") as f:
    tokenizer = pickle.load(f)
with open("inspection_ranges.json", "r", encoding="utf-8") as f:
    RANGE_TABLE = json.load(f)

# === 2. 補助関数 ===
def sample_from_range(name, cat):
    if name not in RANGE_TABLE or cat not in RANGE_TABLE[name]:
        return np.nan
    low, high = RANGE_TABLE[name][cat]
    if np.isnan(low) or np.isnan(high) or low >= high:
        return np.nan
    mean, std = (low + high) / 2, (high - low) / 6
    val = np.random.normal(mean, std)
    return round(float(np.clip(val, low, high)), 1)

def restore_value(text):
    m = re.search(r"検査[:：]\s*([A-Za-z0-9一-龥\-]+)\s*[:：]\s*(低|正常|高)", text)
    if not m:
        return text
    name, cat = m.groups()
    val = sample_from_range(name, cat)
    return f"検査: {name}:{val}"

def generate(seed, steps=40, temperature=1.0):
    text = " ".join(seed)
    generated = seed.copy()
    for _ in range(steps):
        seq = tokenizer.texts_to_sequences([text])
        seq = tf.keras.preprocessing.sequence.pad_sequences(seq, maxlen=500, padding='post')
        preds = model.predict(seq, verbose=0)[0]
        preds = np.log(preds + 1e-8) / temperature
        probs = np.exp(preds) / np.sum(np.exp(preds))
        idx = np.random.choice(len(probs), p=probs)
        word = tokenizer.index_word.get(idx, "")
        if not word:
            break
        generated.append(word)
        text += " " + word
    return [restore_value(t) for t in generated]

# === 3. サンプル生成 ===
seed = [
    "診断: ICD10:E11 2型糖尿病 (+0d)",
    "検査: HbA1c:高 (+0d)",
    "処方: YJ:1234567 メトホルミン錠 (+0d)"
]
timeline = generate(seed, steps=40, temperature=1.2)

# === 4. 出力 ===
df_out = pd.DataFrame({
    "synthetic_patient_id": [f"SYNTH_{int(time.time()*1000)}"] * len(timeline),
    "event_order": range(1, len(timeline) + 1),
    "event_text": timeline
})
df_out.to_csv("synthetic_events_with_values.csv", index=False, encoding="utf-8-sig")

print("💾 synthetic_events_with_values.csv を出力しました。")
